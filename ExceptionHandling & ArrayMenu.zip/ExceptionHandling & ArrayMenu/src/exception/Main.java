package exception;

import java.io.*;
import java.util.Scanner;

/**
 * Main class
 */
public class Main {

    /**
     * writeToFile used for writing to file
     *
     * @param filename as filename
     * @param line     as string data
     * @throws IOException
     */

    public static void writeToFile(String filename, String line) throws IOException {
        File file = new File(filename);
        FileWriter fileWriter = new FileWriter(file, true);
        fileWriter.write(line);
        fileWriter.close();
    }


    /** 
     * writeError method writes each error for each file and reports which error type it is and which record it came from
     * 
     * @param fileName file name
     * @param line     line
     * @param e        error
     * @throws IOException can throw IOException
     */
    public static void writeError(String fileName, String line, String e, String actualfileName) throws IOException {
        File syntaxErrorFile = new File(fileName);
        FileWriter fileWriter = new FileWriter(syntaxErrorFile, true);
        fileWriter.write("error in file: " + actualfileName + "\n");
        fileWriter.write("================\n");
        fileWriter.write("error: " + e + "\n");
        fileWriter.write("record: " + line + "\n\n");
        fileWriter.close();
    }

    /**
     *  readFileContent reads the contents of the file, it splits the string approptiately and stores the information as a BookData object
     * 
     * @param line     line
     * @param fileName file name
     * @return BookData
     * @throws Exceptions.TooManyFieldsException can throw TooManyFieldsException
     * @throws Exceptions.UnknownGenreException  can throw UnknownGenreException
     * @throws Exceptions.MissingFieldException  can throw MissingFieldException
     */
    public static BookData readFileContent(String line, String fileName) throws Exceptions.TooManyFieldsException, Exceptions.UnknownGenreException, Exceptions.MissingFieldException {
        File syntaxErrorFile = new File("genre_store/syntax_error_file.txt");
        if (!syntaxErrorFile.exists()) {
            try {
                syntaxErrorFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String[] hasQuote = line.split("\"");
        String[] content = line.split(",");
        String[] contentList = null;
        if (hasQuote.length > 1) {
            String data = hasQuote[1];
            content = hasQuote[2].split(",");
            contentList = new String[content.length];
            contentList[0] = data;

            for (int i = 1; i < content.length; i++) {
                contentList[i] = content[i];
            }
        } else {
            contentList = content;
        }

        // check if less number of fields present
        if (contentList.length > 6) {
            throw new Exceptions.TooManyFieldsException("too many fields");
        } 
        else if (contentList.length < 6) {

        	if (!contentList[contentList.length - 1].matches("[0-9]+")) {			//if last field
                throw new Exceptions.MissingFieldException("Missing field (YEAR)");
            } 
            if (contentList[0].equals("")) {
            	throw new Exceptions.MissingFieldException("Missing field (TITLE)");
            }
            if (contentList[1].equals("")) {
            	throw new Exceptions.MissingFieldException("Missing field (AUTHOR)");
            }
            if (contentList[2].equals("")) {
            	throw new Exceptions.MissingFieldException("Missing field (PRICE)");
            } 
            if (contentList[3].equals("")) {
            	throw new Exceptions.MissingFieldException("missing field (ISBN)");
            } 
            if (contentList[4].equals("")) {
            	throw new Exceptions.MissingFieldException("missing field (GENRE)");
            }
            if (!contentList[4].equals("CCB") || !contentList[4].equals("HCB") || !contentList[4].equals("MTV") || !contentList[4].equals("MRB") 
            		|| !contentList[4].equals("NEB") || !contentList[4].equals("OTR") || !contentList[4].equals("SSM") || !contentList[4].equals("TPA")) {
            			throw new Exceptions.UnknownGenreException("Unknown Genre");
            		}
        }

        BookData bookData = new BookData(contentList);
        return bookData;
    }
   
    /**
     * part1 implements the follow methods: getAllFileNames(), readFileContent(), writeError(). It filters the genres, and reports errors for tooManyFields, UnknownGenre and MissingField
     *
     * @throws IOException can throw IOException
     */
    public static void do_part1() throws IOException {

        File dir2 = new File("genre_store_2");
        if (!dir2.exists()) {
            dir2.mkdir();
        }

        String[] allFileNames = null;
        try {
            allFileNames = getAllFileNames("part1_input_file_names.txt");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }


        for (String fileName : allFileNames) {
            File newFile = new File(fileName);
            if (newFile.exists()) {
                Scanner individualFileReader = new Scanner(newFile);
                while (individualFileReader.hasNextLine()) {
                    String line = individualFileReader.nextLine();
                    BookData bookData = null;
                    try {
                        bookData = readFileContent(line, fileName);
                    } catch (Exceptions.TooManyFieldsException e) {
                        writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    } catch (Exceptions.MissingFieldException e) {
                        writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);

                        continue;
                    } catch (Exceptions.UnknownGenreException e) {
                        writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    }

                    if (bookData == null) {
                        continue;
                    }
                    String genre = bookData.getGenre();
                    File genreFile = null;
                    switch (genre) {
                        case "CCB":
                            genreFile = new File("genre_store/Cartoons_Comics_Books.csv.txt");
                            break;
                        case "HCB":
                            genreFile = new File("genre_store/Hobbies_Collectibles_Books.csv.txt");
                            break;
                        case "MTV":
                            genreFile = new File("genre_store/Movies_TV.csv.txt");
                            break;
                        case "MRB":
                            genreFile = new File("genre_store/Music_Radio_Books.csv.txt");
                            break;
                        case "NEB":
                            genreFile = new File("genre_store/Nostalgia_Eclectic_Books.csv.txt");
                            break;
                        case "OTR":
                            genreFile = new File("genre_store/Old_Time_Radio.csv.txt");
                            break;
                        case "SSM":
                            genreFile = new File("genre_store/Sports_Sports_Memorabilia.csv.txt");
                            break;
                        case "TPA":
                            genreFile = new File("genre_store/Trains_Planes_Automobiles.csv.txt");
                            break;
                        default:
                            genreFile = null;
                            break;
                    }

                    if (genreFile == null) {
                        continue;
                    }

                    if (!genreFile.exists()) {
                        genreFile.createNewFile();
                    }

                    FileWriter fileWriter = new FileWriter(genreFile, true);
                    fileWriter.write(line + "\n");
                    fileWriter.close();
                }
            } else {
                System.out.println(fileName + "File does not exist");
            }
        }


    }

    /**
     * validatePrice, reports an error if the price is negative
     *
     * @param bookData book data
     * @throws Exceptions.BadPriceException custom exception
     */

    public static void validatePrice(BookData bookData) throws Exceptions.BadPriceException {
        double price = bookData.getPrice();
        if (price < 0) {
            throw new Exceptions.BadPriceException("invalid price");
        }
    }

    /**
     * validateYear reports an error if the book's year is under 1994 or above 2010
     *
     * @param bookData book data
     * @throws Exceptions.BadYearException custom exception
     */
    public static void validateYear(BookData bookData) throws Exceptions.BadYearException {
        int year = bookData.getYear();
        if (year < 1995 || year > 2010) {
            throw new Exceptions.BadYearException("invalid year");
        }
    }

    /**
     * validateISBN validates isbn10 and isbn13 standards, takes each number and mutiplies it by a specific value, then performing multiplication 
     * by specific values depending on the amount of numbers. Errors are report and recorded for badISBN10 and 13, as well as invalid number of 
     * elements
     *
     * @param bookData book data
     * @throws Exceptions.BadIsbn10Exception custom exception
     * @throws Exceptions.BadIsbn13Exception custom exception
     */

    public static void validateIsbn(BookData bookData) throws Exceptions.BadIsbn10Exception, Exceptions.BadIsbn13Exception, Exceptions.InvalidNumberOfElements {

        try {
            String isbn = bookData.getIsbn();

            if (isbn.length() != 10 || isbn.length() != 13) {
                new Exceptions.InvalidNumberOfElements("invalid number of elements");
            }

            String lastCharacter = String.valueOf(isbn.charAt(isbn.length() - 1));
            int isbnLength = isbn.length();
            /// get sum of all digits in isbn
            int sum = 0;
            if (lastCharacter.equals("X") || lastCharacter.equals("x")) {
                if (isbnLength == 10) {
                    int[] digitAdder = new int[]{
                            10, 9, 8, 7, 6, 5, 4, 3, 2, 1
                    };
                    for (int i = 0; i < 9; i++) {
                        int digit = Integer.parseInt(String.valueOf(isbn.charAt(i)));
                        sum += digit * digitAdder[i];
                    }
                    sum += 10;
                    if (sum % 11 != 0) {
                        throw new Exceptions.BadIsbn10Exception("invalid ISBN-10");
                    }

                } else {

                    int[] digitAdder = new int[]{
                            1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1
                    };
                    for (int i = 0; i < 12; i++) {
                        int digit = Integer.parseInt(String.valueOf(isbn.charAt(i)));
                        sum += digit * digitAdder[i];
                    }
                    sum += 10;
                    if (sum % 10 != 0) {
                        throw new Exceptions.BadIsbn13Exception("invalid ISBN-13");
                    }
                }
            }  
        }
        finally {}   
    }
    

    /**
     * part2 assignment sorts for invalid pricing, invalid year and invalid ISBN and puts them in semantic error file, and sorts out XfieldExceptions in syntax error file
     *
     * @throws IOException                       custom exception
     * @throws Exceptions.UnknownGenreException  custom exception
     * @throws Exceptions.TooManyFieldsException custom exception
     * @throws Exceptions.MissingFieldException  custom exception
     */
    public static void do_part2() throws IOException, Exceptions.UnknownGenreException, Exceptions.TooManyFieldsException, Exceptions.MissingFieldException {

        File dir2 = new File("genre_store_2");
        File dir = new File("genre_store");
        if (!dir2.exists()) {
            dir2.mkdir();
        }

        if (!dir.exists()) {
            System.out.println("genre_store directory does not exist");
            return;
        }


        /** Returns an array of abstract pathnames denoting the files in the directory denoted by this abstract pathname */
        for (File file : dir.listFiles()) {
            String fileName = file.getName();
            System.out.println(fileName);
            if (!fileName.equals("syntax_error_file.txt") && !fileName.equals("semantic_error_file.txt")) {
                Scanner fileReader = new Scanner(file);

                FileOutputStream fos = new FileOutputStream("byte_store/" + fileName + ".ser");
                ObjectOutputStream oos = new ObjectOutputStream(fos);

                while (fileReader.hasNextLine()) {
                    String line = fileReader.nextLine();
                    BookData bookData = null;
                 //   try {
                        bookData = readFileContent(line, file.getName());
                        try {
                        	if (bookData.getGenre().equals("")) {
                        		throw new Exceptions.MissingFieldException("Missing field (Genre)");
                        	}
                        }
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                       } 
                        
                        try {
                        	if (bookData.getIsbn().equals("")) {
                        		throw new Exceptions.MissingFieldException("Missing field (ISBN)");
                        	}
                        }
                        
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                        }
                        
                        try {
                        	 if (bookData.getYear() == 0) {
                        	throw new Exceptions.MissingFieldException("Missing field (Year)");
                        	}
                        }
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                        }
                        
                        try {
                        	if (bookData.getPrice() == 0) {
                        		throw new Exceptions.MissingFieldException("Missing field (Price)");
                        	}
                        }
                        
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                        }
                        try {
                        	if (bookData.getTitle().equals("")) {
                        		throw new Exceptions.MissingFieldException("Missing field (Title)");
                        	}
                        }
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                        }
                        try {
                        	if (bookData.getAuthor().equals("")) {
                        		throw new Exceptions.MissingFieldException("Missing field (Author)");
                        	}
                        }
                        catch (Exceptions.MissingFieldException e) {
                        	writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        	continue;
                        }
                
                    
                    try {
                        validateIsbn(bookData);
                    } catch (Exceptions.BadIsbn10Exception e) {
                        writeError("genre_store_2/semantic_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    } catch (Exceptions.BadIsbn13Exception e) {
                        writeError("genre_store_2/semantic_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    } catch (Exception e) {
                        writeError("genre_store_2/syntax_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    }
                    try {
                        validateYear(bookData);
                    } catch (Exceptions.BadYearException e) {
                        writeError("genre_store_2/semantic_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    }
                    try {
                        validatePrice(bookData);
                    } catch (Exceptions.BadPriceException e) {
                        writeError("genre_store_2/semantic_error_file.txt", line, e.getMessage(), fileName);
                        continue;
                    }

                    writeToFile(dir2.getName() + "/" + fileName, line + "\n");

                    oos.writeObject(bookData);
                 }

                oos.close();
                fos.close();


            }
        }

        for (File delfile : dir.listFiles()) {
            if (!delfile.isDirectory()) {
                delfile.delete();
            }
        }
        dir.delete();

    }

    /**
     * part3 of assignment loops through all binary files and keeps count of the files being processed
     */
    public static void do_part3() {
        File dir = new File("byte_store");
        if (!dir.exists()) {
            System.out.println("byte_store directory does not exist");
            return;
        }

        File[] files = dir.listFiles();
        int idx = 0;
        while (true) {
            performChoice(files[idx]);
            idx = (idx + 1) % files.length;
        }
    }

    /**
     * perform choice main menu prompts the user for input and executes their choice
     *
     * @param file file to read
     */

    public static void performChoice(File file) {
        System.out.println("----------------------------------------");
        System.out.println("               MAIN MENU");
        System.out.println("----------------------------------------");
        System.out.println("v - View the selected file: " + file.getName());
        System.out.println("s - Select a file to view");
        System.out.println("x - Exit");

        System.out.print("Enter your choice: ");
        Scanner choiceScannernew = new Scanner(System.in);
        String choice = choiceScannernew.nextLine();
        switch (choice) {
            case "v": 
             
                try { 

                    String fileName = file.getName();
                    System.out.print(String.format("Viewing file: %s", fileName));
                    int totalRecords = readBinaryContent(file, false);
                    System.out.println(String.format(" (Records %d)", totalRecords));
                    Scanner numberScanner = new Scanner(System.in);
                    BookData[] bookData = getAllBookData(totalRecords, file);
                    int currentPointer = 0;
                    System.out.print("\nPlease enter how many files you'd like to see... \nNote: 0 will bring you back to the main menu \nEnter Your Choice: ");
                    while (true) {

                        try {
                            int n = numberScanner.nextInt();
                            System.out.println();
                            if (n == 0) {
                                break;
                            }

                            int prevPointer = currentPointer;
                            currentPointer += n;

                            if (prevPointer > currentPointer) {
                                int temp = prevPointer;
                                prevPointer = currentPointer;
                                currentPointer = temp;
                            }

                            if(n < 0){
                                prevPointer+=1;
                                currentPointer+=1;
                            }

                            for (int i = prevPointer; i < currentPointer; i++) {
                                if (i > currentPointer) {

                                    continue;
                                }

                                if (i < 0) {

                                    continue;
                                }

                                System.out.println(bookData[i]);
                                
                            }
                            currentPointer -= 1;
                            if(n < 0 && n!=-1){
                                currentPointer-=1;
                            }

                            if(currentPointer < 0){
                                currentPointer = 0;
                                System.out.println("EOF has been reached");
                            } else if (currentPointer >bookData.length -1) {
                                currentPointer = bookData.length -1;
                                System.out.println("EOF has been reached");
                            }


                        }
                        
                        catch (Exception e) {
                            if(currentPointer < 0){
                                currentPointer = 0;
                            } else 
                            	if (currentPointer > bookData.length -1) {
                                currentPointer = bookData.length -1;
                            }
                            System.out.println("EOF has been reached");
                        }


                    }

                } catch (Exception e) {
                    System.out.println("EOF has been reached");
                }
                break;
            case "s":
                displayAllFileNames();
                break;
            case "x":
            	System.out.println("Thank you for using our Virtual Book Keeper!\nNow exiting the program.");
                System.exit(0);
                break;
            default:
                System.out.println("invalid choice");
                break;
        }

    }

    /**
     * display all files in byte_store directory
     */
    public static void displayAllFileNames() {
        File fileNames = new File("byte_store");
        System.out.println("----------------------------------------");
        System.out.println("               FILE Sub-Menu");
        System.out.println("----------------------------------------");
        int idx = 1;
        for (File file : fileNames.listFiles()) {
            String fileName = file.getName();
            int totalRecords = readBinaryContent(file, false);
            System.out.println(idx + " " + fileName + " (" + totalRecords + " records)");
            idx++;
        }
        System.out.println(fileNames.listFiles().length + 1 + " Exit");
        System.out.println("----------------------------------------");
        System.out.print("Enter Your Choice: ");
        Scanner choiceScanner = new Scanner(System.in);
        int choice = choiceScanner.nextInt();
        if (choice == fileNames.listFiles().length + 1) {
            System.exit(0);
        }
        File file = new File(fileNames.listFiles()[choice - 1].getName());
        performChoice(file);


    }

    /**
     * getAllBookData reads the serialized objects and returns an array of the BookData objects
     *
     * @param file         file to read
     * @param totalRecords for integer value
     * @return number of records in file
     */

    public static BookData[] getAllBookData(int totalRecords, File file) {
        int idx = 0;
        if (!file.exists()) {
            file = new File("byte_store/" + file.getName());
            return getAllBookData(totalRecords, file);
        }
        BookData[] bookData = new BookData[totalRecords];
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {

                    bookData[idx] = (BookData) ois.readObject();
                    idx++;
              
                } catch (ClassNotFoundException e) {

                }
            }

        } catch (IOException e) {

        }
        return bookData;

    }
/**
 * readBinaryContent reads the contents and counts the number of objects read from it
 * 
 * @param file
 * @param getRecords
 * @return
 */
    public static int readBinaryContent(File file, boolean getRecords) {
        int count = 0;
        if (!file.exists()) {
            file = new File("byte_store/" + file.getName());
            return readBinaryContent(file, getRecords);
        }
        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {

                    BookData book = (BookData) ois.readObject();
                    if (getRecords) {
                        System.out.println(book.toString());
                    }
                    count++;
                    
                } catch (ClassNotFoundException e) {

                }
            }

        } catch (IOException e) {

        }
        return count;
    }

    /**
     * read all content inside binary file
     *
     * @param file file to read
     * @return int
     */

    public static int readBinaryContent(File file) {
        return readBinaryContent(file, false);
    }

    /**
     * getAllFileNames reads the file and returns an array of strings with the names of all files in the input file
     *
     * @param rootFileName root file name
     * @return String[] fileNames
     * @throws FileNotFoundException file not found
     */
    public static String[] getAllFileNames(String rootFileName) throws FileNotFoundException {
        String[] fileNames = null;

        File file = new File(rootFileName);
        Scanner scan = new Scanner(file);
        boolean firstPass = true;
        int idx = 0;
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            if (firstPass) {
                firstPass = false;
                fileNames = new String[Integer.parseInt(line)];
                continue;
            }
            fileNames[idx] = line;
            idx += 1;

        }

        return fileNames;
    }

    /**
     * Driver main method implements do_part1, do_part2, do_part3
     *
     * @param args args
     * @throws Exception exception
     */

    public static void main(String[] args) throws Exception {
        File genreStore = new File("genre_store");
        if (!genreStore.exists()) {
            genreStore.mkdir();
        }

        /** creates new directory in the file chosen */
        File byteStore = new File("byte_store");
        if (!byteStore.exists()) {
            byteStore.mkdir();
        }


        do_part1();
        do_part2();
        do_part3();


    }
}
