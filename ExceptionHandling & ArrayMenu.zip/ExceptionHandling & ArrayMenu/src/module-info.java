/**
 * 
 */
/**
 * @author andra
 *
 */
module exception {
}