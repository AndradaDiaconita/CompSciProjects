//----------------------------------------------------
/** Assignment 4
 *  COMP 249
 *  Written by: Andrada Diaconita & Melanie Szubiak
 *  Due Date: March 29th, 2023
 */
//----------------------------------------------------
package bookstore.src;

//** This class contains all the exceptions that are thrown by the program*/
public class Exceptions {


    /**
     * This exception is thrown when there are too many fields in the file
     */
    public static class TooManyFieldsException extends Exception {
        /**
         * This exception is thrown when there are too many fields in the file
         * @param message The message to be displayed when the exception is thrown
         */
        public TooManyFieldsException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when there are too few fields in the file
     */

    public static class TooFewFieldsException extends Exception {
        /**
         * This exception is thrown when there are too few fields in the file
         * @param message The message to be displayed when the exception is thrown
         */
        public TooFewFieldsException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when a field is missing from the file
     */
    public static class MissingFieldException extends Exception {
        /**
         * This exception is thrown when a field is missing from the file
         * @param message The message to be displayed when the exception is thrown
         */

        public MissingFieldException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when the genre is not one of the following:
     */
    public static class UnknownGenreException extends Exception {
        /**
         * This exception is thrown when the genre is not one of the following:
         * @param message The message to be displayed when the exception is thrown
         */
        public UnknownGenreException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when the ISBN is not 11 characters long
     */

    public static class BadIsbn13Exception extends Exception {
        /**
         * This exception is thrown when the ISBN is not 11 characters long
         * @param message The message to be displayed when the exception is thrown
         */
        public BadIsbn13Exception(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when the price is not a double
     */

    public static class BadPriceException extends Exception {
        /**
         * This exception is thrown when the price is not a double
         * @param message The message to be displayed when the exception is thrown
         */
        public BadPriceException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when the year is not an integer
     */
    public static class BadYearException extends Exception {
        /**
         * This exception is thrown when the year is not an integer
         * @param message The message to be displayed when the exception is thrown
         */
        public BadYearException(String message) {
            super(message);
        }
    }

    /**
     * This exception is thrown when the ISBN is not 10 characters long
     */

    public static class BadIsbn10Exception extends Exception {
        /**
         *  This exception is thrown when the ISBN is not 10 characters long
         * @param message The message to be displayed when the exception is thrown
         */
        public BadIsbn10Exception(String message) {
            super(message);
        }
    }

    public static class InvalidNumberOfElements extends Exception{
        /**
         * his exception is thrown when the ISBN is not having valid numbers
         * @param message the message is to display about the exception thrown
         */

        public InvalidNumberOfElements(String message) { super(message);}
    }


}
