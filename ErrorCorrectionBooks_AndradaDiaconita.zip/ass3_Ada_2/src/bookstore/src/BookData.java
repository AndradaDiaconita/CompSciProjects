//----------------------------------------------------
/** Assignment 4
 *  COMP 249
 *  Written by: Andrada Diaconita & Melanie Szubiak
 *  Due Date: March 29th, 2023
 */
//----------------------------------------------------
package bookstore.src;

import java.io.Serializable;

/**
 * Bookclass
 */
public class BookData implements Serializable {

    /**
     * Title of the book
     */
    public String title;
    /**
     * Author of the book
     */
    public String author;

    /**
     * Price of the book
     */
    public double price;

    /**
     * ISBN of the book
     */
    public String isbn;

    /**
     * Genre of the book
     */
    public String genre = "";

    /**
     * Year of the book
     */
    public int year;

    /**
     * Constructor for the BookData class
     * @param contentList The list of content to be added to the book
     */
    public BookData(String[] contentList) {
        this.title = contentList[0].trim();
        this.author = contentList[1].trim();
        this.price = Double.parseDouble(contentList[2].trim());
        this.isbn = contentList[3].trim();
        this.genre = contentList[4].trim();
        this.year = Integer.parseInt(contentList[5].trim());
    }

    /**
     * Gets the title of the book
     * @return The title of the book
     */

    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the book
     * @param title The title of the book
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the author of the book
     * @return The author of the book
     */

    public String getAuthor() {
        return author;
    }

    /**
     *  Sets the author of the book
     * @param author The author of the book
     */

    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Gets the price of the book
     * @return The price of the book
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price of the book
     * @param price The price of the book
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the ISBN of the book
     * @return The ISBN of the book
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * Sets the ISBN of the book
     * @param isbn The ISBN of the book
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * gets the genre of the book
     * @return The genre of the book
     */

    public String getGenre() {
        return genre;
    }

    /**
     * Sets the genre of the book
     * @param genre The genre of the book
     */

    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Gets the year of the book
     * @return The year of the book
     */
    public int getYear() {
        return year;
    }

    /**
     * Sets the year of the book
     * @param year The year of the book
     */
    public void setYear(int year) {
        this.year = year;
    }


    @Override
    public String toString() {
        return  "{Title = '" + title + '\'' +
                ", Author = '" + author + '\'' +
                ", Price = " + price +
                ", ISBN = '" + isbn + '\'' +
                ", Genre = '" + genre + '\'' +
                ", Year = " + year +
                '}';
    }
}
